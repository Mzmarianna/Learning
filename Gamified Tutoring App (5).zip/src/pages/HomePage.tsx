import { useNavigate } from 'react-router';
import GameHomePage from './GameHomePage';

export default function HomePage() {
  return <GameHomePage />;
}