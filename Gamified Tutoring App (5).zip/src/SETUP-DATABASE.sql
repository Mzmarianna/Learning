-- ============================================================================
-- 🏰 MZ. MARIANNA'S ACADEMY - ONE-CLICK DATABASE SETUP
-- ============================================================================
--
-- 📋 INSTRUCTIONS:
-- 1. Copy this ENTIRE file (Ctrl+A, Ctrl+C)
-- 2. Go to: https://supabase.com/dashboard/project/wyclbrafklhvdyjpoeno/sql/new  
-- 3. Paste (Ctrl+V) and click "Run"
-- 4. Done! 🎉
--
-- ============================================================================

-- NOTE: Ignore "already exists" errors - that's normal if re-running!

